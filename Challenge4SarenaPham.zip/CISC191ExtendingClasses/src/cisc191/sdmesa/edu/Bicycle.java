package cisc191.sdmesa.edu;

import java.awt.Color;

/**
 * Lead Author(s):Sarena Pham
 * @author 
 * @author 
 * <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 * <<add additional contributors (mentors, tutors, friends) here, with contact information>>
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * <<https://youtu.be/YoSghxkxBVQ, https://youtu.be/NnZQ-C0x4hs, https://youtu.be/5X0Y--92pMI>>
 *  //cite sources 
 * 
 *  
 * Version/date: 3/6/22*
 * 
 * Responsibilities of class:
 * A a Bicycle is a Cycle with two wheels
 */
/**
 */
public class Bicycle extends Cycle
{
	//color can change
	private Color newColor;
	
	//bicycle uses super constructor from cycle
	//constructor initialize newMake. 
	public Bicycle(String newMake)
	{
		super(newMake);
	}
	
	// initializes newColor
	public Bicycle(String newMake, Color newColor)
	{
		super(newMake);
		this.newColor = newColor;
	}
	
	//bicycle has 2 wheels
	@Override
	int getNumberOfWheels()
	{
		// TODO Auto-generated method stub
		return 2;
	}
	
	//set and get new color
	@Override
	void setColor(Color newColor) 
	{
		//bicycle has own color
		this.newColor = newColor;
		
	}
	
	@Override
	Color getColor()
	{
		// TODO Auto-generated method stub
		return newColor;
	}

}
