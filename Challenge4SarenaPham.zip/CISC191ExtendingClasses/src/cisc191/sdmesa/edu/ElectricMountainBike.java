package cisc191.sdmesa.edu;

import java.awt.Color;

/**
 * Lead Author(s):Sarena Pham
 * @author 
 * @author 
 * <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 * <<add additional contributors (mentors, tutors, friends) here, with contact information>>
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * <<add more references here>>
 *  
 * Version/date: 
 * 
 * Responsibilities of class:
 * ElectricMountainBike is a Bicyle that is Movable, Gearable, and Electric
 */
/**
 */
public class ElectricMountainBike extends Bicycle implements Movable, Gearable, Electric
{
	//electric mountain bike(emc) has a speed
	private int speed = 0;
	//emc has a gear
	private int gear = 1;
	//emc has a charge
	private int charge;
	
	//electric mountain bike(emc) uses super constructor
	public ElectricMountainBike(String newMake)
	{
		super(newMake);
	}
	
	//emc uses bicycle's 2nd constructor
	public ElectricMountainBike(String newMake, Color newColor)
	{
		super(newMake, newColor); 
	}
	
	//description of emc
	@Override
	public String getDescription()
	{
		return super.getMake()+" "+super.getNumberOfWheels()+" wheels "+super.getColor();
	}
	
	//implement interface movable
	public int getSpeed()
	{
		return speed;
	}
	
	
	//implement interface gearable
	public int getGear() 
	{
		// TODO Auto-generated method stub
		return gear;
	}
	
	//set charge to 100 from test
	public void charge(int charge)
	{
		this.charge = charge;
	}
	
	//implement interface electric
	public int getCharge()
	{
		return charge;
	}
		
	//overide toString of object class
	public String toString()
	{
		return "ElectricMountainBike: make: "+super.getMake()+" wheels: "+super.getNumberOfWheels()+" color: "+super.getColor();
	}
	

	public boolean equals(Object object)
	{
	
		//if parameter object is a cycle
		if( object instanceof ElectricMountainBike )
		{
			//create electricmountainbike object. cast object to a electricmountainbike type
			//emc stand for electricmountainbike
			ElectricMountainBike emc = (ElectricMountainBike) object;
			
			//compare "this bike" with cycle, 
			//return true if both make and both color are equal
			//check for equality with object of this class
			if( emc.getMake().equals( this.getMake() ) && emc.getColor().equals( this.getColor()) )
			{
				return true;
			}
			
		}
		return false;
	}
}
