package cisc191.sdmesa.edu;

public interface Electric 
{
	//method to set/get charge
	void charge(int charge);
	int getCharge();
}
