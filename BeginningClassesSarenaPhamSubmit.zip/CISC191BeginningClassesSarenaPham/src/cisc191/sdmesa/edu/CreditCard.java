package cisc191.sdmesa.edu;

public class CreditCard 
{

	//credit card has a number
	private String number;
	//credit card has expiration
	private String expiration;
	//credit card has security
	private String security;
	
	//credit card class has a person object
	private Person person;
	
	//constructor take in parameters, initialize variables
	
	public CreditCard(String number, String expiration, String security, Person person)
	{
		this.number = number;
		this.expiration = expiration;
		this.security = security;
		this.person = person;
	}

	//get methods 
	
	public String getNumber()
	{
		return number;
	}
	
	public String getExpire()
	{
		return expiration;
	}
	
	public String getSecurity()
	{
		return security;
	}
	
	public Person getPerson()
	{
		return person;
	}
	
	public String toString()
	{
		return number+" "+expiration+" "+security+" "+person.getName();
	}
	
}
