package cisc191.sdmesa.edu;

public class Person {
	
	//person has a name
	private String name;
	//person has a phone
	private String phone;
	//person has a zip
	private String zip;

	//constructor initialize variables to parameters it took in
	public Person(String name, String phone, String zip)
	{
		this.name = name;
		this.phone = phone;
		this.zip = zip;
	}
	
	//get methods. 
	public String getName()
	{
		return name;
	}
	
	public String getPhone()
	{
		return phone;
	}
	
	public String getZip()
	{
		return zip;
	}
	
	public String toString()
	{
		return name+" "+phone+" "+zip;
	}
	
	
}
