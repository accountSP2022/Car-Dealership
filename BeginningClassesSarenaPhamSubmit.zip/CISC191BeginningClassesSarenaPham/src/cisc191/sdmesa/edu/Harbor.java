package cisc191.sdmesa.edu;

public class Harbor 
{
	
	//harbor has many boats
	private Boat[] stock;
	
	
	//constructor initializes variable from parameter it take in
	public Harbor(int size)
	{
		//5 boats in the array of boats
		stock = new Boat[size];
		
	}
	
	public Boat getBoatAt(int slipNumber)
	{
		return stock[slipNumber];
	}
	
	//return what is at place before reassign
	public Boat parkBoatAt(Boat otherBoat, int slipNumber)
	{
		//start with empty parking lot
		//temp boat to store stock[place], return temp 
		
		Boat temp = stock[slipNumber];
		
		//set boat in array = to param boat
		//park boat at specific place
		
		stock[slipNumber] = otherBoat;
		
		//parking space is empty AT FIRST 
		
		return temp;
	}
	
	// needed get method, changes inventory array
	public Boat[] getInventory()
	{
		Boat[] inventory = new Boat[stock.length];
		//deep copy of stock array into inventory array
		//inventory = stock;    reference, not deep  copy. changing inventory will change stock incorrect
		
		for(int i = 0; i < stock.length; i++)
		{
			inventory[i] = stock[i];
		}
		return inventory;
		
	}
}
