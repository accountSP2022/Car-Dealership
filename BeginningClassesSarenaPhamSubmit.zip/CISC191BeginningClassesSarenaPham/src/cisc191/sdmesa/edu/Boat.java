package cisc191.sdmesa.edu;

import java.awt.Color;

/**
 * Lead Author(s):Sarena Pham
 * @author 
 * @author 
 * <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 * <<add additional contributors (mentors, tutors, friends) here, with contact information>>
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * <<add more references here: stack overflow static int>>
 *  
 * Version/date: 2/27/22
 * 
 * Responsibilities of class:
 * 
 */
/**
 */
public class Boat
{
	//boat has a make
	private String make;
	//boat has a color
	private Color color;
	//boat has a speed
	private int speed = 0;
	//boat has a price
	private int price = -1;
	//boat has a serialNumber
	private static int serial_Number = 1;
	//boat has a serial Number
	private int serialNumber;
	
	/**
	 * Purpose: 
	 * 
	 * @param
	 * @return 
	 */
	public Boat(String make, Color color)
	{
		//initialize parameters
		this.make = make;
		this.color = color;
			
		//initialize serial number to new serial number created
		this.serialNumber = createNewSerialNumber();
	}
	
	public Boat() 
	{
		//empty constructor
	}
	
	//get methods 2nd
	
	public String getMake()
	{
		return make;
	}

	public Color getColor()
	{
		return color;
	}

	public int getSpeed()
	{
		return speed;
	}
	
	public int getPrice()
	{
		return price;
	}
	
	public int getSerialNumber()
	{
		return serialNumber;
	}
	//set methods 1st
	
	public void setColor(Color color)
	{
		this.color = color;
	}
	
	public void setPrice(int price)
	{
		this.price = price;
	}
	
	//accumulator methods
	
	public void speedUp()
	{	
		speed += 1;
	}
	
	public void slowDown()
	{
		speed -= 1;
	}
	
	//to string
	public String toString()
	{
		return "Boat: make: "+make+" color: "+color;
	}
	
	
	public boolean equals(Object comparedBoat)
	{
		
		//empty boat
		if( comparedBoat == null )
		{
			return false;
		}
		
		//create new instance of boat, set it equal to paramater boat 
		Boat boat = (Boat) comparedBoat;
			
		//compare "this" boat to b, see if they are equal
		if( this.make.equals( boat.make ) && this.color.equals( boat.color ))
		{
			return true;
		}
		
		//boats not equal 
		return false;
	}
	
	public static int createNewSerialNumber()
	{
		//serial number is local int. local int gets destroyed after method runs
		//static int keeps value and can be incremented as method runs. static int cannot be destroyed.
		//return static int through local int
		int serialNumber = serial_Number++;
		return serialNumber;
		
	}
	
}
