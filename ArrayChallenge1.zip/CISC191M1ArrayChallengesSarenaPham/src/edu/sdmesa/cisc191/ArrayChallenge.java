package edu.sdmesa.cisc191;

/**
 * Lead Author(s):
 * @author 
 * @author 
 * <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 * <<add additional contributors (mentors, tutors, friends) here, with contact information>>
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * <<add more references here>>
 *  
 * Version/date: 
 * 
 * Responsibilities of class:
 * 
 */
/**
 * Sarena Pham
 * Professor 
 * Classmate
 */
public class ArrayChallenge
{
	/**
	 * Purpose: Find the largest element in the array given
	 * 
	 * @param array to search
	 * @return largest element
	 */
	public static int max(int[] array)
	{
		//initialize int with 1st index of array
		int greatestValue = array[0];
		
		//start loop at 1 since greatestValue is already index 0 of array.
		//don't need to compare same values
		for(int i = 1; i < array.length; i++)
		{
			//if index after greatestValue has bigger value, 
			if(greatestValue < array[i])
			{
				//set greatestValue to the bigger value
				greatestValue = array[i];
			}
			
		}
		
		return greatestValue;
	} 
	
	// Use this template for the other methods
	/**
	 * Purpose: Find smallest element in given array
	 * 
	 * @param array search
	 * @return smallest element
	 */
	public static int min(int[] array)
	{
		//initialize int with 1st index of array
				int leastValue = array[0];
				
				//start loop at 1 since leastValue is already 1st element of array.
				//don't need to compare same values
				for(int i = 1; i < array.length; i++)
				{
					//if element after leastValue has smaller value
					if(leastValue > array[i])
					{
						//set leastValue to the smaller value
						leastValue = array[i];
					}
					
				}
				
				return leastValue;
	}
	
	// Use this template for the other methods
		/**
		 * Purpose: Find sum of all elements in array
		 * 
		 * @param array search
		 * @return sum of all elements
		 */
	public static int sum(int[] array)
	{
		int sum = 0;
		
		//if array empty return 0 as sum
     	if(array.length == 0)
		{
			return 0;
		}
     	
     	//if array not empty set sum = to 1st element in array
		else
		{
		    sum = array[0];
		
		    // add together all elements in array
		for(int i = 1; i < array.length; i++)
		{
			sum += array[i];
		}
		}
		return sum;
}
	
	// Use this template for the other methods
		/**
		* Purpose: Find test average of elements in aray
	    * 
	    * @param array search
		* @return average of all elements
	    */
	public static double average(int[] array)
	{
		int sum = 0;
		double length = array.length;
		double avg = 0.0;
		
		//sum of all elements
		for( int i = 0; i < array.length; i++)
		{
			sum += array[i];
		}
		
		//calculate average
		avg = sum/length;
		return avg;
	}
	
	// Use this template for the other methods
		/**
		 * Purpose: Find median of elements in array
		 * 
		 * @param array search
		 * @return median of all elements
		 */
	public static double median(int[] array)
	{
		int sum = 0;
		double median = 0;
		int length = array.length;
		
		 
		//even array length
		if(length % 2 == 0)
		{
			for(int i = 0; i < array.length; i++)
			{
				sum += array[i];
			}
			median = sum / length;
		}
		
		//odd array length
		else
		{
			//int division rounds decimal down. Mid is index of median element
			int mid = length / 2; 
			median = array[mid];
		}
		return median; 
	}
	
}
