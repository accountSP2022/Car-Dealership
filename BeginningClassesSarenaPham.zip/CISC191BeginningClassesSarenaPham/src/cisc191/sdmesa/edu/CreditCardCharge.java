package cisc191.sdmesa.edu;

public class CreditCardCharge 
{
	//credit card charge has a year
	private int year;
	//credit card charge has a month
	private int month;
	//credit card charge has a day
	private int day;
	//credit card charge has a boat
	private Boat purchasedBoat;
	//credit card charge has a company name
	private String companyName;
	//credit card charge has a credit card
	private CreditCard chargedCard;
	
	
	//constructor takes in parameters, initializes variables
	public CreditCardCharge(int year, int month, int day, Boat purchasedBoat, String companyName, CreditCard chargedCard)
	{
		this.year = year;
		this.month = month;
		this.day = day;
		this.purchasedBoat = purchasedBoat;
		this.companyName = companyName;
		this.chargedCard = chargedCard;
	}
	
	//combine toString methods of different objects for final result
	public String toString()
	{
		return year+"/"+month+"/"+day+" "+chargedCard.toString()+companyName+purchasedBoat.getMake()+" $"+purchasedBoat.getPrice();
	}

}
