package edu.sdmesa.cisc191;

import java.lang.reflect.Array;

/**
 * Lead Author(s):
 * @author Sarena Pham
 * @author 
 * <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 * <<add additional contributors (mentors, tutors, friends) here, with contact information>>
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * <<add more references here>>
 *  
 * Version/date: 2/27/22
 * 
 * Responsibilities of class:
 * 
 */
/**
 * Sarena Pham
 */
public class M2ArrayChallenge
{
	

	/**
	 * Purpose: check if array contain int value
	 * 
	 * @param array to search
	 * @return boolean true or false
	 */
	public static boolean contains(int[] array, int value)
	{
		for( int i = 0; i < array.length; i++)
		{
			//stop for loop once value is found in array
			if( array[i] == value)
			{
				return true;
			}
		}
		//no value found
		return false;
	}
	
	// Use this template for the methods
	/**
	 * Purpose:find returns the first index of a value in an array,
	 * or -1 if the value is not in the array
	 * 
	 * @param array
	 * @return 1st index of a value in the array
	 */
	public static int find(int[] array, int value)
	{
	
		for( int i = 0; i < array.length; i++)
		{
			//found value in array at index. return index
			if( array[i] == value)
			{
				return i;
			}
		}
		//value not in array
		return -1;
	}
	
	// Use this template for the methods
	/**
	* Purpose: count instances of user specified number
	* @param array
	* @return how many times  number appears
	*/
	public static int countValues( char[] array, int value)
	{
		int count = 0;
		for(int i = 0; i < array.length; i++)
		{
			//count how many times that number appears in array
			if(array[i] == value)
			{
				count++;
			}
		}
		return count;
	}
	
	// Use this template for the methods
	/**
	* Purpose: count instances of user specified letter
	* @param array
	* @return amount of times letter appears
	*/
	public static int countValues( char[] array, char letter)
	{
		int count = 0;
		for(int i = 0; i < array.length; i++)
		{
			//count how many times that letter appears in array
			if(array[i] == letter)
			{
				count++;
			}
		}
		return count;
	}

	// Use this template for the methods
	/**
	 * Purpose: check if array least to greatest
	 * @param array
	* @return true/false
	*/
	
	public static boolean inOrder(int[] array)
	{
		//element will not go out of bound if i < array.length-1	
		for(int i = 0; i < array.length-1; i++)
		{
			//if not least to greatest
			if(array[i] > array[i+1])
			{
				return false;
			}
			
		}
		//in order
		return true;
		
	}
	// Use this template for the methods
	/**
	* Purpose: The bubbleUp method does one pass of an array. no repeating
	* @param array
	* @return sorted array
	*/
	
	public static int[] bubbleUp(int[] array) 
	{
		int store = 0;
		
		//no out of bound
		for(int i = 0; i < array.length-1; i++)
		{
			//if left element greater than right
			if( (array[i] > array[i+1] ))
			{
				//swap
				store = array[i];
				array[i] = array[i+1];
				array[i+1] = store;
			}
			
		}
		
		return array;
	}
	
	
//	/**
//	 * The bubbleSort method sorts an array.
//	 * Hint: while the elements are not in order, repeatedly use bubbleUp
//   * @param array
//   * @return new array sorted
//	 */
	
	//use in order and bubble up  
	public static int[] bubbleSort(int[] array) 
	{
		//while array not sorted
		while(!inOrder(array)) 
		{
			//call bubble up. 1 pass through array.
			bubbleUp(array);
						
		}
		
		return array;
	}
//	
//	// Use this template for the methods
//	/**
//	* Purpose: return new array exact same as original
//	* @param array
//	* @return new array exact same as original
//	*/
	public static char[] copy(char[] array)
	{
		//new array, same length as original
		char copy[] = new char[array.length];
		 
		for(int i = 0; i < array.length; i++)
		{
		   //make copy same as original
		   copy[i] = array[i];
		   
		}
		
		return copy;
	}
	
	// Use this template for the methods
	/**
	* Purpose: return array with elements backward
	* @param array
	* @return array backwards
	*/
	public static char[] backwards(char[] array)
	{
		//index of copy
		int copyIndex = 0;
		//create copy array
		char copy[] = new char[array.length];
			
		//copyindex is different from arrayindex
		//increment copyindex (start at 0) while decrement arrayindex (start at array.length-1). 
		//set element at copyindex = to element at arrayindex.
		//that creates a copy array that is backwards from original array
		for(int arrayIndex = array.length-1; arrayIndex >= 0; arrayIndex--)
		{
			copy[copyIndex] = array[arrayIndex];
			copyIndex++;
		}
	    
				
		return copy;
	}
	
	// Use this template for the methods
	/**
	* Purpose: check if array is palindrome
	* @param array
	* @return true/false
	*/
	public static boolean isPalindrome(char[] array)
	{
		//create backward array. call backwards method and array is parameter
		char[] backward =  backwards(array);
		
		
		for(int arrayIndex = 0; arrayIndex < array.length; arrayIndex++ )
		{
			//if original array not equal to backward array, they are not palindrome
			if( array[arrayIndex] != backward[arrayIndex])
			{
				return false;
			}
		}
		return true;
	}
	
	
	// Use this template for the methods
	/**
	* Purpose: get element at specified place in matrix
	* @param 2d array
	* @return element int
	*/
	public static int getElement(int[][] matrix, int row, int col)
	{
		//get element at specific row and column
		return matrix[row][col];
	}
	
	// Use this template for the methods
	/**
	* Purpose: add elements in specified row
	* @param array
	* @return int sum
	*/
	public static int sumRow(int[][] matrix, int row)
	{
		int sum = 0;
		
		//focus on 1 row, add together columns left to right
		for(int i = 0; i < matrix[0].length; i++)
		{
			sum += matrix[row][i];
		}
		return sum;
	}
	

	// Use this template for the methods
	/**
	* Purpose: add elements in specified column
	* @param array
	* @return int sum
	*/
	public static int sumColumn(int[][] matrix, int col)
	{
		int sum = 0;
		
		//to add up column, col stays same, increment rows
		for(int i = 0; i < matrix.length; i++)
		{
			sum += matrix[i][col];
		}
		return sum;
	}
	
	
	// Use this template for the methods
	/**
	* Purpose: add elements in square 2d array, left to right diagonal
	* @param array
	* @return int sum
	*/
	public static int sumLeftToRightDiagonal(int[][] matrix)
	{
		int sum = 0;
		
		//row and column increase together to add diagonals
		for(int i = 0; i < matrix.length; i++)
		{
			sum += matrix[i][i];
		}
		return sum;
	}
	
	// Use this template for the methods
	/**
	* Purpose: add together diagonal, start at top row, last column
	* @param array
	* @return int sum
	*/
	public static int sumRightToLeftDiagonal(int[][] matrix)
	{
		int sum = 0;
		int row = 0;
		
		//empty array return 0
		if(matrix.length <= 0 || matrix[0].length <= 0)
		{
			return 0;
		}
		
		//add together right to left diagonal
		for(int col = matrix[0].length-1; col >= 0; col--)
		{
			sum += matrix[row++][col];
		}
		return sum;
	}
		
	// Use this template for the methods
	/**
	* Purpose: add together last column of each row
	* @param array
	* @return int sum
	*/	
	public static int sumLastRowElements(int[][] matrix)
	{
		int sum = 0;
		
		for(int rows = 0; rows < matrix.length; rows++)
		{
			//each row can have different amount of columns
			int cols = matrix[rows].length-1;
			sum += matrix[rows][cols];
		}
		return sum;
	
	}

	
}
