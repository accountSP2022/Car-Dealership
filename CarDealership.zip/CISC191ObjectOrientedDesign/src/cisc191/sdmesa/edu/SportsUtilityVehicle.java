package cisc191.sdmesa.edu;

public class SportsUtilityVehicle extends Vehicle
{
	//sports utility vehicle is a vehicle. extends
	
	//sports utility vehicle has a max tow weight
	private int maxTowWeight;
	
	//use super constructor from vehicle
	public SportsUtilityVehicle(String manufacturerName, int miles, int price, int seats, Option[] listOptions, int maxTowWeight)
	{
		super(manufacturerName, miles, price, seats, listOptions);
		this.maxTowWeight = maxTowWeight;
	}

	public int getMaxTowingWeight()
	{
		return maxTowWeight;
	}
}
