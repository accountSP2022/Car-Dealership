package cisc191.sdmesa.edu;

/**
 * Lead Author(s):Sarena Pham
 * @author 
 * @author 
 * <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 * <<add additional contributors (mentors, tutors, friends) here, with contact information>>
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * <<javajavajava textbook>>
 *  
 * Version/date: 3/6/2022*
 * 
 * Responsibilities of class:
 * 
 */
/**
 */
public class Vehicle
{
	// TODO fill in the instance variables/fields
	
	//object aggregation
	//vehicle has a manufacturer name
	private String manufacturerName;
	//vehihcle has a miles amount
	private int miles;
	//vehicle has a price
	private int price;
	//vehicle has a seat amount
	private int seats;
	//vehicle has many options, store each option in array. u
	//get method to get specific option at array index
	private Option[] listOptions;

	// TODO fill in a constructor
	
	public Vehicle(String manufacturerName, int miles, int price, int seats, Option[] listOptions )
	{
		this.manufacturerName = manufacturerName;
		this.miles = miles;
		this.price = price;
		this.seats = seats;
		this.listOptions = listOptions;
		
	}

	// TODO fill in the methods from the UML
	//get methods 
	public String getManufacturerName()
	{
		return manufacturerName;
	}
	
	public int getMilesOnVehicle()
	{
		return miles;
	}
	
	public int getPrice()
	{
		return price;
	}
	
	public int getNumberOfSeats()
	{
		return seats;
	}
	
	public Option[] getOptions()
	{
		return listOptions;
	}
}
