package cisc191.sdmesa.edu;

public class HybridCar extends Car implements Combustible, Chargeable
{
	//hybrid car is a car. extends
	
	//hybrid car has a fuel level
	private int fuelLevel;
	//static int to increment fuel level by 100. 
	private static int fuellevel = 100;
	//hybrid car has a battery charge
	private int batteryCharge;
	//static int to increment battery charge by 100.
	private static int batterycharge = 100;
	
	public HybridCar(String manufacturerName, int miles, int price, int seats, Option[] listOptions, int doors)
	{
		super(manufacturerName, miles, price, seats, listOptions, doors);
	}

	//hybrid car is combustible, is chargeable. implements
	
	public void tankUp()
	{
		//fuelLevel  is local int. local int gets destroyed after method runs
		//fuellevel int keeps value of 100.  static int cannot be destroyed.
		//return value of static int through local int
		fuelLevel += fuellevel;
	}
	
	public int getFuelLevel()
	{
		return fuelLevel;
	}
	
	//increment battery charge by 100
	public void chargeUp()
	{
		batteryCharge += batterycharge;
	}
	
	public int getBatteryCharge()
	{
		return batteryCharge;
	}
}
