package cisc191.sdmesa.edu;

public class ElectricCar extends Car implements Chargeable
{
	//electric car is a car. extends
	
	//electric car has a battery charge
	private int batteryCharge;
	//static int to increment battery charge by 100
	private static int batterycharge = 100;
	
	public ElectricCar(String manufacturerName, int miles, int price, int seats, Option[] listOptions, int doors)
	{
		super(manufacturerName, miles, price, seats, listOptions, doors);
	}

	//electric car is chargeable. implements
	public void chargeUp()
	{
		batteryCharge += batterycharge;
	}
	
	public int getBatteryCharge()
	{
		return batteryCharge;
	}
}
