package cisc191.sdmesa.edu;

public interface Combustible 
{
	//methods
	void tankUp();
	int getFuelLevel();
	

}
