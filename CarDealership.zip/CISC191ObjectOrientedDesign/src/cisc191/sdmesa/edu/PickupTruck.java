package cisc191.sdmesa.edu;

public class PickupTruck extends Vehicle
{
	//pickup truck is a vehicle. extends
	
	//pickup truck has a cargo capacity
	private int cargoCapacity;
	
	//use super constructor of vehicle
	public PickupTruck(String manufacturerName, int miles, int price, int seats, Option[] listOptions, int cargoCapacity )
	{
		super(manufacturerName, miles, price, seats, listOptions);
		this.cargoCapacity = cargoCapacity;
	}

	public int getCargoCapacity()
	{
		return cargoCapacity;
	}
}
