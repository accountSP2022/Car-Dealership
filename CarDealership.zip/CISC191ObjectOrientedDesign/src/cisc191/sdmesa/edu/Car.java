package cisc191.sdmesa.edu;

public class Car extends Vehicle
{
	//car is a vehicle
	
	//car has a doors
	private int doors;
	public Car(String manufacturerName, int miles, int price, int seats, Option[] listOptions, int doors )
	{
		super(manufacturerName, miles, price, seats, listOptions);
		this.doors = doors;
	}
	
	//get method
	public int getNumberOfDoors()
	{
		return doors;
	}

}
