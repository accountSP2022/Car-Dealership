package cisc191.sdmesa.edu;

public class Option 
{

	//option has a detail
	private String detail;
	
	//constructor initializes option
	public Option(String detail)
	{
		this.detail = detail;
	}
	
	//returns option string
	public String getDetails()
	{
		return detail;
	}
	
	
}
